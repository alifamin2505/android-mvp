package com.example.mvpsimple

interface MainView {
    fun updateLuas(luas: Float)
    fun updatekeliling(keliling: Float)
    fun showError(errorMsg: String)
}