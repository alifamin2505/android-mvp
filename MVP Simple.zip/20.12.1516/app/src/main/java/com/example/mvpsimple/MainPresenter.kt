package com.example.mvpsimple

class MainPresenter(private val mainView: MainView) {
    fun hitungLuasPersegiPjg(panjang: Float, lebar: Float) {
        if (panjang == 0F){
            mainView.showError(errorMsg = "Panjang tidak boleh 0")
            return
        }
        if (lebar == 0F) {
            mainView.showError(errorMsg = "Lebar tidak boleh 0")
            return
        }
          val luas = panjang * lebar
        mainView.updateLuas(luas)
    }

    fun hitungKelilingPersegiPjg(panjang: Float, lebar: Float){

        if (panjang == 0F){
            mainView.showError(errorMsg = "Panjang tidak boleh 0")
            return
        }
        if (lebar == 0F) {
            mainView.showError(errorMsg = "Lebar tidak boleh 0")
            return
        }
        val keliling = 2*(panjang+lebar)
        mainView.updatekeliling(keliling)


    }

}